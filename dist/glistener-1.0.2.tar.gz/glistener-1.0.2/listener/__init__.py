# coding=utf-8
# author: lifangyi
# date: 2021/4/12 下午3:15
# file: __init__.py

from .gpu_standalone_listener import main